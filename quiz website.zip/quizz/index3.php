<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>quiz website</title>
    <link rel="stylesheet" href="style5.css">

</head>
<body>
    <main class="main">
        <header class="header">
            <a href="#" class="logo">Quiz.</a>

            <nav class="navbar">
                
                <ul>
                <li><a href="index2.php"> Home</a></li>
                <li><a href="../log.php"> Login</a></li>
                </ul>
            </nav>
        </header>
        <section class="home">
            <div class="home-content">
                <h1>Quiz Website</h1>
               <a href="index2.php" class="start-btn"> Start Quiz</a>
            </div>
        </section>
    </main>
</body>
</html>