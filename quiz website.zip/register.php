<?php

include 'connect2.php';
if(isset($_POST['signUp'])){
    $firstName=$_POST['fName']; 
    $lastName=$_POST['lName'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $password=md5($password);

    $checkEmail="SELECT * From user2 where email='$email'";
    $result=$conn->query($checkEmail);
    if($result->num_rows>0){
        echo " Email Address Already Exists !";
    }
    else{
        $insertQuery="INSERT INTO user2(firstName,lastName,email,password) VALUES ('$firstName','$lastName','$email','$password')";
        if($conn->query($insertQuery)==TRUE){
            header("location:log.php");
        }

        else{
            echo "Error:".$conn->error;
        }
    }
}
if(isset($_POST['signIn'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    $password=md5($password);

    $sql="SELECT * FROM user2 WHERE email='$email' and password='$password'";
    $result=$conn->query($sql);
    if($result->num_rows>0){
        session_start();
        $row=$result->fetch_assoc();
        $_SESSION['email']=$row['email'];
        header("Location: ./pahadi/index.php");
        exit();
    }
    else{
        echo " Not found , Incorrect Email or Password";
    }
}

?>